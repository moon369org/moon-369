# Moon Press Kit

## logo/
Wordmark with linked O's. SVG (vector) + PNG (2400px wide).
- moon-wordmark-cream / black: transparent background
- moon-wordmark-cream-on-dark / black-on-cream: with background

## mark/
The linked-O mark alone, same four variants. PNG at 1200px.

## app-icon/
Rounded-square icons, dark and cream. SVG + 1024 / 512 PNG.
64 and 32 px versions use a heavier stroke with no link gap so they stay legible.

## loader/
- moon-loader.html: standalone full-screen loader, open in any browser
- moon-loader.svg: self-animating SVG, drop into an <img> or inline
Breathe, 3.2s loop: solid circle breathes into two rings and back, no pause. Edit animation-duration to change speed.

## badges/
"Powered by Moon" badges, dark and light. SVG with outlined text, plus 4x PNG.

## social/
X avatar (400px), X banner (1500x500) and the "A new standard for time" photo.

## colors/
- moon-colors.css: CSS variables
- moon-colors.json: tokens
- moon-palette.png / .svg: swatch sheet

Fonts (Google Fonts, free): Syncopate (display, uppercase, wide tracking), Inter (text), JetBrains Mono (data).
